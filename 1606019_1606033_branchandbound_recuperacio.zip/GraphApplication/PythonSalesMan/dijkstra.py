import graph
import math
import sys
import queue

# Dijkstra =====================================================================

def minDistance(vertices, visitats):                    #Funció per trobar el node amb la distancia menor per a l'execució del Dijkstra normal
    minim=math.inf
    res=""
    for v in vertices:
        if v not in visitats and v.DijkstraDistance < minim:
            minim = v.DijkstraDistance
            res = v
    return res

def Dijkstra(g,start):
    cami = {start: None}
    for i in g.Vertices:                                 #Inicialitzem tots els nodes a infinit
        i.DijkstraDistance = sys.float_info.max
    start.DijkstraDistance = 0
    visitats = {}                                       #Diccionari per a guardar els nodes visitats
    
    for i in range(len(g.Vertices)-1):                  #Iterar sobre tots els vertexs del graf
        start = minDistance(g.Vertices, visitats)       #Cridem a la funció minDistance per a agafar la distància mínima
        visitats[start] = 1
        for e in start.Edges:                           #Mira tots els nodes veïns
            if not visitats.get(e):                     #Comprova que el veï no estigui visitat
                if e.Destination.DijkstraDistance > start.DijkstraDistance + e.Length:
                    e.Destination.DijkstraDistance = start.DijkstraDistance + e.Length
                    cami[e.Destination] = start

    return cami                                         #Retornem el cami final


# DijkstraQueue ================================================================

def DijkstraQueue(g,start):
    cua = queue.PriorityQueue()                         #Inicialitzem la cua de prioritat
    cami = {start: None}
    for i in g.Vertices:                                #Inicialitzem tots els nodes a infinit
        i.DijkstraDistance = sys.float_info.max
    start.DijkstraDistance = 0
    visitats = {}                                       #Diccionari per a guardar els nodes visitats
    
    cua.put((start.DijkstraDistance, start))            #Afegim el primer node i la seva distància a la cua de prioritat

    while not cua.empty():                              #Repeteix mentre la cua no estigui buida
        actual = cua.get()                              #Agafa el primer element de la cua (el de menor distància)
        visitats[actual] = 1
        for i in actual[1].Edges:                       #Mira tots els nodes veïns         
            if not visitats.get(i):                     #Comprova que el veï no estigui visitat
                if i.Destination.DijkstraDistance > actual[0] + i.Length:          
                    i.Destination.DijkstraDistance = actual[0] + i.Length
                    cua.put((i.Destination.DijkstraDistance, i.Destination))
                    cami[i.Destination] = actual[1]     #Afegim el node seleccionat al cami final

    return cami                                         #Retornem el cami final