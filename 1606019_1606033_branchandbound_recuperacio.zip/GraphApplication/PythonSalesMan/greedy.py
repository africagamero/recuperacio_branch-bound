
import graph
import math
import sys
import queue
import dijkstra

# SalesmanTrackGreedy ==========================================================

def SalesmanTrackGreedy(g,visits):
    camino=graph.Track(g)
    inicio = visits.Vertices[0]
    final = visits.Vertices[-1]
    vertices = visits.Vertices[1:-1]

    while len(vertices)>0:
        aux= graph.Track(g)
        dist=sys.float_info.max
        dijkstra.Dijkstra(g,inicio)
        for nodo in vertices:
            if nodo.DijkstraDistance < dist:
                dist= nodo.DijkstraDistance
                nodo_actual=nodo
                auxi_nodo=nodo
        while nodo_actual != inicio:
            edge= nodo_actual.ApuntadorArista
            nodo_actual=edge.Origin
            aux.AddFirst(edge)

        camino.Append(aux)
        vertices.remove(auxi_nodo)
        inicio=auxi_nodo
    dijkstra.Dijkstra(g,inicio)
    nodo_actual=final
    aux=graph.Track(g)
    while nodo_actual!=inicio:
        edge=nodo_actual.ApuntadorArista
        nodo_actual=edge.Origin
        aux.AddFirst(edge)
    camino.Append(aux)


    return camino
