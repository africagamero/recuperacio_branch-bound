from ast import Break
#from sympy import Q
import graph
import math
import sys
import queue
import dijkstra
import copy

def cota_min(cota_act, idx_ca, idx, matriu_adj, cami_actO, es_ultim, vis):
    cami_act = copy.copy(cami_actO)
    cami_act.append(idx)
    valor = 0
    for i in range(1, len(cami_act)):
        valor += matriu_adj[cami_act[i-1]][cami_act[i]]
    columnes = list(set(range(len(matriu_adj[0]))) - set(cami_act))
    if len(columnes) == 0:
        return (valor, 0)
    files = copy.copy(columnes)
    files.append(idx)
    files.remove(len(matriu_adj[0]) - 1)
    if not es_ultim:
        val_nc = matriu_adj[idx][len(matriu_adj[0]) - 1]
    else:
        val_nc = None
    aux = 0
    for i,c in enumerate(zip(*matriu_adj)):
        if i in columnes:
            s_col = sorted(c)
            v_col = [i for i in s_col if c.index(i) in files and i != val_nc]
            if 0 not in v_col:
                aux += v_col[0]
            else:
                aux += v_col[1]
    return (valor, valor + aux)
            
        
def cota_max(cota_act, idx_ca, idx, matriu_adj, cami_actO, es_ultim):
    cami_act = copy.copy(cami_actO)
    cami_act.append(idx)
    valor = 0
    for i in range(1, len(cami_act)):
        valor += matriu_adj[cami_act[i-1]][cami_act[i]]
    columnes = list(set(range(len(matriu_adj[0]))) - set(cami_act))
    if len(columnes) == 0:
        return valor
    files = copy.copy(columnes)
    files.append(idx)
    files.remove(len(matriu_adj[0]) - 1)
    if not es_ultim:
        val_nc = matriu_adj[idx][len(matriu_adj[0]) - 1]
    else:
        val_nc = None
    aux = 0
    for i,c in enumerate(zip(*matriu_adj)):
        if i in columnes:
            s_col = sorted(c, reverse=True)
            v_col = [i for i in s_col if c.index(i) in files and i != val_nc]
            aux += v_col[0]
    return valor + aux

# SalesmanTrackBranchAndBound2 ===================================================

def SalesmanTrackBranchAndBound2(g, visits):
    vis = visits.Vertices
    matriu_adj = []
    camins = {}
    for i in vis[:-1]:
        camins[i] = dijkstra.DijkstraQueue(g, i)
        matriu_adj.append([v.DijkstraDistance for v in vis])

    cota_sup = 0
    cota_inf = 0
    desti = vis[-1]
    for i in zip(*matriu_adj):
        cota_sup += max(i)
        if (0 not in i) or len(i) == 1:
            cota_inf += min(i)
        else:
            cota_inf += sorted(i)[1]
    
    cua_cuotes = queue.PriorityQueue()
    col_zero = [r[0] for r in matriu_adj]
    if len(i) == 1:
        cua_cuotes.put((cota_inf - min(col_zero) + matriu_adj[0][0], cota_sup - max(col_zero) + matriu_adj[0][0], [0]))
    else:
        cua_cuotes.put((cota_inf - sorted(col_zero)[1] + matriu_adj[0][0], cota_sup - max(col_zero) + matriu_adj[0][0], [0]))
    cota_global = cota_sup - max(col_zero) + matriu_adj[0][0]
    solucio = []
    while True: # posar una condició per acabar
        cami_act = cua_cuotes.get()
        if cami_act[-1][-1] == len(vis) - 1:
            solucio = copy.copy(cami_act)
            break
        new_cota = cota_global
        for idx,node in enumerate(vis):
            if idx not in cami_act[2]:
                if node != desti or len(cami_act[2]) == len(vis) - 1:
                    (dist, c_min) = cota_min(cami_act[0], cami_act[2][-1], idx, matriu_adj, cami_act[2], len(cami_act[2]) == len(vis) - 2, vis)
                    c_max = cota_max(cami_act[1], cami_act[2][-1], idx, matriu_adj, cami_act[2], len(cami_act[2]) == len(vis) - 2)
                    if (c_max - c_min) < (cota_global + 1e-5):
                        new_cami = copy.copy(cami_act[2])
                        new_cami.append(idx)
                        cami = (c_min, c_max, new_cami)
                        cua_cuotes.put(cami)
                        if c_max < new_cota:
                            new_cota = c_max
        cota_global = new_cota
    solucio_f = []
    for i in solucio[-1]:
        solucio_f.append(vis[i])
    track = graph.Track(g)
    
    for i in range(1, len(solucio[-1])):
        final = vis[solucio[-1][i]]
        inicial = vis[solucio[-1][i-1]]
        track_aux = graph.Track(g)
        while final != inicial:
            for i in camins[inicial][final].Edges:
                if i.Destination == final:
                    track_aux.AddFirst(i)
                    break
            final = camins[inicial][final]
        track.Append(track_aux)

    return track

# SalesmanTrackBranchAndBound1 ===================================================

def SalesmanTrackBranchAndBound1(g, visits):
    return graph.Track(g)

# SalesmanTrackBranchAndBound3 ===================================================

def SalesmanTrackBranchAndBound3(g, visits):
    return graph.Track(g)