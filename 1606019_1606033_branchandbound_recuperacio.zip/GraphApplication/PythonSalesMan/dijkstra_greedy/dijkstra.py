import graph
import math
import sys
from queue import PriorityQueue

# Dijkstra =====================================================================

def Dijkstra(g,start):
	visitado=[]
	aux=[]
	for vertex in g.Vertices:
		if vertex is not start:
			vertex.DijkstraDistance=math.inf
		else:
			start.DijkstraDistance=0.0
	pActual=start
	while len(visitado)<=len(g.Vertices):
		for edge in pActual.Edges:
			vecino=edge.Destination
			if vecino.DijkstraDistance > (pActual.DijkstraDistance+edge.Length):
				vecino.DijkstraDistance=pActual.DijkstraDistance+edge.Length
				aux.append([vecino,vecino.DijkstraDistance])
			visitado.append(pActual)
		dist=math.inf
		for vecino in aux:
			if vecino[1]<dist:
				pActual=vecino[0]
				aux.remove(vecino)
			
	return 
		

# DijkstraQueue ================================================================
	

def DijkstraQueue(g,start):

	for vertex in g.Vertices:
		if vertex != start:
			vertex.DijkstraDistance=math.inf
			vertex.DijkstraVisit=False        
			#si això no funciona només crea una llista de visitats i vas afegint
			#els nodes allà en comptes de passsar-los a true
		else:
			vertex.DijkstraDistance=0
			vertex.DijkstraVisit=False

	#afegeix a la cua el 'start'
	cua = PriorityQueue()
	cua.put((start.DijkstraDistance,start))

	#mentre al cua no està buida
	while (cua.empty()==False):

		#va = primer element de la cua i treure'l de cua
		aux = cua.get()
		n_actual=aux[1]
		cua.task_done()
	
		#si no està com a visitat
		if n_actual.DijkstraVisit == False:

			#recorrem tots els veins del node
			for edge in n_actual.Edges:
				vei=edge.Destination
				dist=float(edge.Length + n_actual.DijkstraDistance)
				if vei.DijkstraDistance >= dist:
					vei.DijkstraDistance = float(n_actual.DijkstraDistance + edge.Length)
					cua.put(vei)	
	
			#marquem el n_actual com a visitat
			n_actual.DijkstraVisit=True
	return
