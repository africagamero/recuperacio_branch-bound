import graph
import subprocess
import sys
import time
import dijkstra
import greedy
import backtracking

# ==============================================================================
# IDENTIFICACIO DELS ALUMNES ===================================================
# ==============================================================================

graph.NomAlumne1 = "Àfrica"
graph.CognomsAlumne1 = "Gamero López"
graph.NIUAlumne1 = "1606033"

# No modificar si nomes grup d'un alumne

graph.NomAlumne2 = "Èlia"
graph.CognomsAlumne2 = "Vinyes Devesa"
graph.NIUAlumne2 = "1606019"

# VERIFICAR ALUMNES =============================================================

graph.TestNIU(graph.NIUAlumne1)
if graph.NIUAlumne2!="": graph.TestNIU(graph.NIUAlumne2)


# EXECUCIO EN PROCESS DE CORRECCIO ==============================================

if graph.CorrectionProcess(): sys.exit(0)

# ==============================================================================
# PROVES =======================================================================
# ==============================================================================

g=graph.Graph()                     # crear un graf
g.Load("TestDijkstra/Graf4.GR")     # llegir el graf
g.SetDistancesToEdgeLength()        # Posar les longituts de les arestes a la distancia entre vertexs
start=g.GetVertex("Start");         # Obtenir el vertex origien de les distancies (distancia 0)
t0 = time.time()                    # temps inicial
dijkstra.Dijkstra(g,start)          #Cerca cami que pasi per les visites
t1 = time.time()                    # Temps final
print("temps: ",t1-t0)              # imprimir el temps d'execució
g.DisplayDistances()                # Visualitza el track i les visites sobre el graf