import graph
import math
import sys
from queue import PriorityQueue
import operator

# Dijkstra =====================================================================


def Dijkstra(g,start):
    # Primer creem un diccionari "distancies", amb el que treballarem 
    # durant tota la execució, on la key es l'objecte vertex i 
    # el value serà una llista amb la DijkstraDistance i el node anterior
    # (el node anterior no ho necessitem ara, pero si per greedy)
    # Les distancies de tots els nodes al inici serà infinit, excepte
    # la distancia del node per el que començem
    distancies = {v:[sys.float_info.max, None] for v in g.Vertices}
    distancies[start] = [0, None]
    
    # Inicialitzem una llista, on afegirem cada node que modifiquem la distancia
    # per tal de seguir amb l'algoritme per aquests nodes, i no els que encara
    # no hem modificat perquè no hem arribat (ja que podria donar-se el cas de
    # que algun node estigues separat, per tant, sempre tindria distancia = inf)
    nodes = []
    nodes.append([0, start, None])
    
  
    visitats = []

    
    while nodes != []:
        
        nodes = sorted(nodes, key = operator.itemgetter(0))
       
        actual = nodes.pop(0)
        visitats.append(actual[1])
        
      
        for vei in actual[1].Edges:
            # Comprovarem que no hem visitat el vei, per tant, no tornem enrere
            if vei.Destination not in visitats:
                # Haurem de comprovar si el camí que estem mirant ara tingui
                # una distancia menor a la que ja haviem trobat
                if (distancies[actual[1]][0] + vei.Length) < distancies[vei.Destination][0]:
                    # Si ens interessa aquest cami perquè es mes curt, haurem
                    # d'afegir el node a la llista per saber que hem visitar-lo
                    nodes.append([(distancies[actual[1]][0] + vei.Length), vei.Destination, vei.Origin])
                    # Haurem de modificar el diccionari distancies, ja que aqui
                    # guardem les solucions
                    distancies[vei.Destination] = [(distancies[actual[1]][0] + vei.Length), vei.Origin.Name]
    
    # Una vegada ha acabat de mirar tots els nodes i ha acabat l'algorisme,
    # modificarem els atributs del graf. Per tant, mirem cada vertex de g
    for vertex in g.Vertices:
        
        vertex.DijkstraDistance = distancies[vertex][0]
       
        vertex.Anterior = distancies[vertex][1]
    return distancies	
	
		

# DijkstraQueue ================================================================
	


import queue

def DijkstraQueue(g,start):
	#1. Inicialitzar les distancies dels vèrtex a infinit excepte la del vèrtex start que serà 0 
	#2. Marcar tots el vèrtex com no visitats
	visitat = {}

	for vertex in g.Vertices:
		visitat[vertex] = False
		vertex.DijkstraDistance = sys.float_info.max
	start.DijkstraDistance = 0.0


	cua = queue.PriorityQueue()
	cua.put((start.DijkstraDistance , start))

	while not cua.empty(): #Mentre cua no buida
		
		va_distance, va = cua.get() #va=primer element de la cua i treure'l de la cua.

		if not visitat[va]: #Si no està marcat com visitat 

			for edge in va.Edges: #Recorre tots el veïns v de va i fer el següent
				vei = edge.Destination
				
				if not visitat[vei]:
					d_nova = va_distance + edge.Length
					if vei.DijkstraDistance > d_nova: #Mirar si distancia és més petita
						vei.DijkstraDistance = d_nova #Actualitzar distancia
						vei.minEdge = edge
						cua.put((vei.DijkstraDistance, vei)) #Afegir vei a la cua
		
			visitat[va] = True

	return





