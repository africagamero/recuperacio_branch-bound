import graph
# import math
import sys
# import queue
import dijkstra
import operator
# import numpy as np
   
# SalesmanTrackBranchAndBound1 ===================================================

def SalesmanTrackBranchAndBound1(g, visits):
    return graph.Track(g)

# SalesmanTrackBranchAndBound2 ===================================================

def crearTaula(g,visits):
    matrix = []
    max_dist = []
    min_dist = []
    maxim = 0
    minim = 0
    for node1 in visits: 
        dijkstra.Dijkstra(g, node1)
        row=[]
        for node2 in visits: #creacio matriu
            distance = node2.DijkstraDistance
            row.append(distance)
        matrix.append(row)

        row_max = max(row[:-1]) 
        row_min = sys.float_info.max
        row = row[:-1]
        trobat = False
        for column in range(len(row)):
            if 0 < row[column] < row_min:
                row_min = row[column]
                trobat = True
        if trobat ==False:
            row_min = 0

        maxim += row_max
        minim += row_min
        max_dist.append(row_max)
        min_dist.append(row_min)
    return matrix,maxim,minim,max_dist,min_dist

def calculsMaxim(maxim, minim, pos = 0):
    if pos == 1:
        if maxim < minim + sys.float_info.max:
            return True
        return False
    if maxim < minim + sys.float_info.max:
        return maxim
    return minim

def calculTrack(g, visits, cami):
    track = graph.Track(g)
    for i in range(len(cami[:-1])):
        dijkstra.Dijkstra(g, visits[cami[i]])
        anterior = visits[cami[i + 1]]
        aresta_anterior = None
        for node in g.Vertices:
            if node.Name == anterior.Anterior:
                for aresta in node.Edges:
                    if aresta.Destination.Name == anterior.Name:
                        aresta_anterior = aresta
        auxiliar = []
        while aresta_anterior != None:
            auxiliar.append(aresta_anterior)
            anterior = aresta_anterior.Origin
            aresta_anterior = None
            for node in g.Vertices:
                if node.Name == anterior.Anterior:
                    for aresta in node.Edges:
                        if aresta.Destination.Name == anterior.Name:
                            aresta_anterior = aresta
        auxiliar.reverse()
        for i in auxiliar:
            track.Edges.append(i)
    return track

def SalesmanTrackBranchAndBound2(g, visits):
    cua = []
    index_visits = list(range(len(visits.Vertices)))
    matriu,maxim,minim,max_list,min_list = crearTaula(g, visits.Vertices)
    matriu.pop()
    minim_max = maxim
    cua.append([minim, maxim, [0]])
    while cua != []:
        cua = sorted(cua, key = operator.itemgetter(0))
        aux = cua.pop(0)    
        # minim = aux[0],  maxim = aux[1],  cami = aux[2]
        if calculsMaxim(minim, minim_max, 1):
            sol = True
            for i in index_visits:
                if i not in aux[2]:
                    sol = False
            if sol == True:
                return calculTrack(g, visits.Vertices, aux[2])
            else:
                for fila in range(len(matriu)): 
                    if fila not in aux[2]:
                        minim_fila = min_list[fila]
                        max_fila = max_list[fila]
                        matrix = matriu[aux[2][-1]][fila]
                        new_min = minim - minim_fila + matrix
                        new_max = maxim - max_fila + matrix
                        minim_max = calculsMaxim(new_max, minim_max)
                        cami = aux[2] + [fila]
                        if len(cami) == len(matriu):
                            minim_row_last = min_list[-1]
                            max_row_last = max_list[-1]
                            matrix = matriu[cami[-1]][-1]
                            new_min = new_min - minim_row_last + matrix
                            new_max = new_max + max_row_last + matrix
                            minim_max = calculsMaxim(new_max, minim_max)
                            cami.append(index_visits[-1])
                        cua.append([new_min, new_max, cami])

        aux[2].append(index_visits[-1])
    return calculTrack(g,visits.Vertices,aux[2]) #funcio que ens dona ja el track

# SalesmanTrackBranchAndBound3 ===================================================

def SalesmanTrackBranchAndBound3(g, visits):
    return graph.Track(g)
	