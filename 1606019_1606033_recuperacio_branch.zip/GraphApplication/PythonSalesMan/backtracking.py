import graph
import math
import sys
import queue
import dijkstra
import copy


def definitiu(g, visits, t):
    if t.Edges == [] or  t.Edges[-1].Destination.Name != visits[-1]:
        return False
    track = []
    track.append(t.Edges[0].Origin.Name)
    for edge in t.Edges:
        track.append(edge.Destination.Name)
    for i in visits:
        if i not in track:
            return False
    return True


def main(g, visits, t, cami, longitud, max_longitud):
    if definitiu(g, visits, t) == True:
        return cami, longitud, max_longitud
                
    if len(t.Edges) != 0:
        v = t.Edges[-1].Destination
    else:
        v = g.GetVertex(visits[0])
    
    for aresta in v.Edges:
        if aresta not in t.Edges:
            if (longitud + aresta.Length) < max_longitud:
                t.Edges.append(aresta)
                if aresta.Destination.Name == visits[-1]:
                    if definitiu(g, visits, t) == True:
                        cami = copy.deepcopy(t)
                        max_longitud = longitud + aresta.Length
                longitud = longitud + aresta.Length
                cami, longitud, max_longitud = main(g, visits, t, cami, longitud, max_longitud)
                t.Edges.pop(-1)
                longitud = longitud - aresta.Length 
    return cami, longitud, max_longitud



def SalesmanTrackBacktracking(g,visits):
    t = graph.Track(g)
    visitats = []
    for v in visits.Vertices:
        visitats.append(v.Name)
    camins = []
    cami, l1, l2 = main(g, visitats, t, camins, 0, math.inf)    
    track = graph.Track(g)
    if type(cami) != list:
        for edge in cami.Edges:
            track.Edges.append(edge)
    return track
