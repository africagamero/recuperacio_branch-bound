
import graph
import math
import sys
import queue
import dijkstra

# SalesmanTrackGreedy ==========================================================

def SalesmanTrackGreedy(g,visits):

    return graph.Track(g)
