import graph
import math
import sys
from queue import PriorityQueue
import operator

# Dijkstra =====================================================================


def Dijkstra(g,start):

    distancies = {v:[sys.float_info.max, None] for v in g.Vertices}
    distancies[start] = [0, None]
    
 
    nodes = []
    nodes.append([0, start, None])
    

    visitats = []


    while nodes != []:

        nodes = sorted(nodes, key = operator.itemgetter(0))
       
        visitats.append(actual[1])
        
        for vei in actual[1].Edges:
           
            if vei.Destination not in visitats:

                if (distancies[actual[1]][0] + vei.Length) < distancies[vei.Destination][0]:

                    nodes.append([(distancies[actual[1]][0] + vei.Length), vei.Destination, vei.Origin])

                    distancies[vei.Destination] = [(distancies[actual[1]][0] + vei.Length), vei.Origin.Name]
    

    for vertex in g.Vertices:

        vertex.DijkstraDistance = distancies[vertex][0]

        vertex.Anterior = distancies[vertex][1]
    return distancies
	
	
		

# DijkstraQueue ================================================================
	


import queue

def DijkstraQueue(g,start):
	#1. Inicialitzar les distancies dels vèrtex a infinit excepte la del vèrtex start que serà 0 
	#2. Marcar tots el vèrtex com no visitats
	visitat = {}

	for vertex in g.Vertices:
		visitat[vertex] = False
		vertex.DijkstraDistance = sys.float_info.max
	start.DijkstraDistance = 0.0


	cua = queue.PriorityQueue()
	cua.put((start.DijkstraDistance , start))

	while not cua.empty(): #Mentre cua no buida
		
		va_distance, va = cua.get() #va=primer element de la cua i treure'l de la cua.

		if not visitat[va]: #Si no està marcat com visitat 

			for edge in va.Edges: #Recorre tots el veïns v de va i fer el següent
				vei = edge.Destination
				
				if not visitat[vei]:
					d_nova = va_distance + edge.Length
					if vei.DijkstraDistance > d_nova: #Mirar si distancia és més petita
						vei.DijkstraDistance = d_nova #Actualitzar distancia
						vei.minEdge = edge
						cua.put((vei.DijkstraDistance, vei)) #Afegir vei a la cua
		
			visitat[va] = True

	return





